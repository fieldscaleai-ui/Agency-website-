import { FormEvent, useEffect, useState } from 'react';
import {
  Apple, ArrowRight, ArrowUpRight, Award, Check, ChartLine, Gamepad2,
  Instagram, LayoutTemplate, Mail, Map, Menu, MessageCircle, PanelsTopLeft,
  Plus, QrCode, Rocket, ScanSearch, Target, TrendingUp, Video,
} from 'lucide-react';

const contactEmail = 'fieldscale.ai@gmail.com';
const instagramUrl = 'https://www.instagram.com/fieldscale.ai?igsh=ZjZ4Y2Q1bGhlM2Y0';
const demosUrl = 'https://drive.google.com/drive/folders/17hE-nMxp5YTbw-vemTc2aFeIflux0YLb';
const whatsappMessage = 'Hi%20FieldScale%20AI%2C%20I%27d%20like%20a%20free%20project%20preview.';
const whatsappContacts = [
  ['+91 91988 99112', `https://wa.me/919198899112?text=${whatsappMessage}`],
  ['+91 73551 89039', `https://wa.me/917355189039?text=${whatsappMessage}`],
] as const;
const whatsappPreview = whatsappContacts[0][1];

function Header() {
  const [open, setOpen] = useState(false);
  const links = [['How it works', '#how'], ['Services', '#services'], ['Pricing', '#pricing'], ['Proof', '#proof'], ['FAQ', '#faq'], ['Contact', '#contact']];
  const go = () => setOpen(false);
  return <header className="site-nav">
    <a href="#top" className="nav-logo" aria-label="FieldScale AI home">fieldscale ai</a>
    <nav className="nav-center">{links.map(([label, href]) => <a key={href} href={href}>{label}</a>)}</nav>
    <div className="nav-right">
      <a className="nav-wa" href={whatsappPreview} target="_blank" rel="noreferrer"><MessageCircle size={15} />WhatsApp</a>
      <a className="nav-cta" href="#contact">Get a free preview <ArrowRight size={15} /></a>
    </div>
    <details className="mobile-menu" open={open} onToggle={(event) => setOpen((event.currentTarget as HTMLDetailsElement).open)}>
      <summary aria-label="Open navigation"><Menu size={20} /></summary>
      <nav>{links.map(([label, href]) => <a onClick={go} key={href} href={href}>{label}</a>)}</nav>
    </details>
  </header>;
}

function Hero() {
  return <section id="top" className="hero reveal">
    <span className="hero-badge"><i /> POWERED BY AI LEAD INTELLIGENCE</span>
    <h1>Don't Just Run Ads. <span>Ship Real Leads</span> &amp; Build a Growth System That Compounds.</h1>
    <p className="hero-sub">Not a typical agency. FieldScale AI is a lead-generation operating system — high-converting websites, scroll-stopping ad creatives, and AI audits that turn attention into booked business.</p>
    <div className="hero-actions">
      <a href="#contact" className="btn btn-primary">Get a free preview <ArrowRight size={16} /></a>
      <a href="#pricing" className="btn btn-ghost">See pricing</a>
      <a href="#how" className="btn btn-dark">How it works</a>
    </div>
  </section>;
}

function Stats() {
  return <section className="stats-section reveal"><div className="stats">
    {['3|Core growth systems', '48h|First draft delivery', '100%|Preview before payment', 'AI|Powered audits'].map((item) => {
      const [value, label] = item.split('|');
      return <div className="stat" key={value}><b>{value}</b><span>{label}</span></div>;
    })}
  </div></section>;
}

const steps = [
  [Target, 'Choose your growth goal', "More leads, more calls, more bookings — define the outcome you're chasing."],
  [Map, 'We map strategy & structure', 'Messaging, funnel logic and creative direction built for your offer.'],
  [Rocket, 'We ship website & ads', 'High-converting pages and scroll-stopping creatives, produced fast.'],
  [ScanSearch, 'AI audit & optimization', "A forensic pass finds leaks and compounds what's already working."],
  [TrendingUp, 'Launch, track & scale', 'Go live, measure results, and expand the channels that convert.'],
] as const;

function SectionHeader({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return <div className="section-header center"><p className="eyebrow">{eyebrow}</p><h2>{title}</h2>{description && <p>{description}</p>}</div>;
}

function HowItWorks() {
  return <section id="how" className="section reveal"><SectionHeader eyebrow="HOW IT WORKS" title="A 5-step loop from attention to booked leads." description="A systematic process designed to turn cold traffic into a compounding growth engine." />
    <div className="steps-loop">{steps.map(([Icon, title, text], index) => <div className="step" key={title}><div className="top"><span className="num">0{index + 1}</span><Icon size={22} /></div><h3>{title}</h3><p>{text}</p></div>)}</div>
  </section>;
}

const outcomes = [
  { tag: 'WEBSITE SYSTEM', icon: LayoutTemplate, title: 'Lead Generation Websites', become: 'The obvious choice online', items: ['Lead-focused landing pages', 'Service-based site structure', 'Conversion contact forms', 'Fast, responsive design'] },
  { tag: 'AD CREATIVE', icon: Video, title: 'Short-Form Ad Creatives', become: 'Impossible to scroll past', items: ['UGC ads for Instagram & Facebook', 'Hook-based scripts', 'Ad-ready vertical videos', 'Multiple test variations'] },
  { tag: 'AI AUDIT', icon: ScanSearch, title: 'AI Audits', become: 'A data-driven operator', items: ['Full funnel & website audit', 'AI automation opportunity map', 'Competitor & creative review', 'Prioritized action report'] },
];

function Services() {
  return <section id="services" className="section reveal"><SectionHeader eyebrow="DEFINED OUTCOMES" title="What you get after working with us." description="Three core systems, each with a clear transformation and real deliverables." />
    <div className="outcome-grid">{outcomes.map(({ tag, icon: Icon, title, become, items }) => <article className="outcome-card" key={title}><div className="top"><span className="tag">{tag}</span><Icon size={22} /></div><h3>{title}</h3><p className="become">Become: <span>{become}</span></p><p className="build-label">What you'll get</p><ul>{items.map(item => <li key={item}><ArrowUpRight size={14} />{item}</li>)}</ul></article>)}</div>
  </section>;
}

const process = [
  ['done', 'Share your details', 'Goals, offer, audience & current position.'],
  ['done', 'Strategy planned', 'Messaging, funnel logic & creative direction.'],
  ['current', 'We build it', 'Website & ads produced, refined, quality-checked.'],
  ['locked', 'Launch & scale', 'Go live, track results, compound what works.'],
];

function Process() {
  return <section id="process" className="section process reveal"><SectionHeader eyebrow="THE PROCESS" title="A sequential build, not a black box." description="Every project moves through four unlocked stages — you always know what's next." />
    <div className="process-track">{process.map(([state, title, text], index) => <div className={`process-step ${state}`} key={title}><span className="process-state">{state}</span><div className="process-dot">{String(index + 1).padStart(2, '0')}</div><h3>{title}</h3><p>{text}</p></div>)}</div>
  </section>;
}

const proof = [
  [ChartLine, 'Live lead tracking', 'A simple dashboard showing leads, cost and conversion — no vanity metrics, just what compounds.'],
  [QrCode, 'QR-verified reports', 'Monthly performance reports with a scannable QR code so stakeholders can verify real results.'],
  [Award, 'Proof of work log', 'Every deliverable ships with a proof-of-work log: what was built, why, and the outcome.'],
] as const;

function Proof() {
  return <section id="proof" className="section reveal"><SectionHeader eyebrow="PROOF OF PERFORMANCE" title="Verified results, not promises." description="We report on outcomes you can actually verify — shared with a single scan." />
    <div className="proof-grid">{proof.map(([Icon, title, text]) => <article className="proof-card" key={title}><div className="icon"><Icon size={24} /></div><h3>{title}</h3><p>{text}</p></article>)}</div>
  </section>;
}

const plans = [
  { title: 'Free Preview', price: '$0', suffix: '/forever', items: ['1 landing page mockup preview', 'AI audit snapshot', 'No payment until you approve', 'Strategy call'], cta: 'Choose Free Preview' },
  { title: 'Starter', price: '$249', items: ['1 high-converting landing page', '5 short-form UGC video ads', '10 ad creatives'], cta: 'Choose Starter' },
  { title: 'Growth', price: '$599', items: ['Full website (3–4 pages)', '10 UGC video ads', 'Google Business Profile optimization', '20 ad creatives'], cta: 'Choose Growth', featured: true },
  { title: 'Dominance', price: '$1,199', suffix: '+ $249/mo', items: ['Full lead-optimized website', '15–20 UGC video ads', 'AI chat assistant', 'Ad setup guidance'], cta: 'Choose Dominance' },
];

function Pricing() {
  return <section id="pricing" className="section reveal"><SectionHeader eyebrow="PRICING PLANS" title="Transparent plans. No retainers." description="Start with a free preview. Upgrade when you're ready to scale." />
    <div className="pricing-grid">{plans.map(plan => <article className={`price-card ${plan.featured ? 'featured' : ''}`} key={plan.title}>{plan.featured && <span className="chosen">MOST CHOSEN</span>}<h3>{plan.title}</h3><div className="price">{plan.price} <small>{plan.suffix}</small></div><ul>{plan.items.map(item => <li key={item}><Check size={15} />{item}</li>)}</ul><a href="#contact" className="btn btn-primary">{plan.cta} <ArrowRight size={15} /></a><p className="price-note">Free preview before final payment</p></article>)}</div>
  </section>;
}

function Manifesto() {
  return <section className="section manifesto-wrap reveal"><div className="manifesto"><SectionHeader eyebrow="THE FIELDSCALE MANIFESTO" title="We're building the agency we wish we'd had." />
    <p>Traditional agencies failed because they sell <span>deliverables, not outcomes</span>. You don't grow by receiving a folder of assets — you grow by <span>shipping systems that compound</span> and seeing proof of what works.</p>
    <div className="tags"><span className="tag-chip"><Gamepad2 size={16} />Gamified delivery</span><span className="tag-chip"><PanelsTopLeft size={16} />Distraction-free systems</span><span className="tag-chip"><Apple size={16} />Premium dark aesthetics</span></div>
  </div></section>;
}

const faqs = [
  ['How is FieldScale different from a traditional agency?', 'Traditional agencies sell hours and deliverables. FieldScale ships a complete lead system — website, ad creatives and AI audits — built around a single outcome: more booked leads. You preview everything before final payment.'],
  ["What's included in the free preview?", 'You get a mockup of your landing page and an AI audit snapshot of your current funnel — no payment required until you approve the direction.'],
  ['How fast do you deliver?', 'First drafts typically land within 48 hours. Full websites and creative batches ship in 1–2 weeks depending on scope.'],
  ['Do I own the website and creative?', 'Yes. Everything we build is yours — fully editable files, hosting-ready code, and raw ad assets included.'],
  ["What's an AI audit?", 'A forensic review of your current funnel, automation and creative to find where attention and revenue leak out — delivered as a prioritized action report.'],
  ['How does the WhatsApp support work?', 'Tap the WhatsApp button anytime to message us directly. We respond during business hours and keep you posted at every stage of your project.'],
];

function FAQ() {
  return <section id="faq" className="section reveal"><SectionHeader eyebrow="CLIENT GUIDE" title="Frequently asked questions." /><div className="faq">{faqs.map(([question, answer]) => <details key={question}><summary>{question}<Plus size={18} /></summary><p>{answer}</p></details>)}</div></section>;
}

function Contact() {
  const [sent, setSent] = useState(false);
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const business = String(data.get('business') ?? '').trim();
    const email = String(data.get('email') ?? '').trim();
    const message = String(data.get('message') ?? '').trim();
    const subject = `New FieldScale AI enquiry from ${business}`;
    const body = [
      `Business name: ${business}`,
      `Reply email: ${email}`,
      '',
      'Message:',
      message,
    ].join('\n');
    window.location.href = `mailto:${contactEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setSent(true);
    form.reset();
  };
  return <section id="contact" className="section reveal"><SectionHeader eyebrow="GET STARTED" title="Your lead engine starts with one preview." description="Tell us where the business is now. We'll show you what the next version could look like — free." />
    <a className="demo-project-cta" href={demosUrl} target="_blank" rel="noreferrer">View Our Demo Project <ArrowUpRight size={16} /></a>
    <div className="contact-grid"><form onSubmit={submit}><label>Business name<input name="business" required placeholder="Your business" /></label><label>Email<input name="email" required type="email" placeholder="you@company.com" /></label><label>Message<textarea name="message" required placeholder="Tell us about your goals" rows={5} /></label><div className="contact-actions"><button className="btn btn-primary" type="submit">Send inquiry <ArrowUpRight size={16} /></button></div><span className="sr-only" role="status">{sent ? 'Inquiry submitted and email composer opened' : ''}</span></form>
       <aside><span className="status"><i />OPEN FOR NEW PROJECTS</span><a href={`mailto:${contactEmail}`}><Mail size={18} />{contactEmail}</a><a href={instagramUrl} target="_blank" rel="noreferrer"><Instagram size={18} />@fieldscale.ai</a>{whatsappContacts.map(([number, href]) => <a className="wa-link" href={href} target="_blank" rel="noreferrer" key={number}><MessageCircle size={18} />{number}</a>)}<p>Strategic websites, ad creative and AI audits for service businesses ready to scale.</p></aside>
    </div>
  </section>;
}

function Footer() {
  const company = [['How it works', '#how'], ['Services', '#services'], ['Pricing', '#pricing'], ['FAQ', '#faq']];
  return <footer><div className="footer-inner"><div><div className="footer-brand">FieldScale AI<span>.</span></div><p>AI-powered lead systems, engineered for action. High-converting websites, scroll-stopping ad creatives, and AI audits that turn attention into booked business.</p></div><div><h4>Company</h4><ul>{company.map(([label, href]) => <li key={href}><a href={href}>{label}</a></li>)}</ul></div><div><h4>Connect</h4><ul><li><a href={`mailto:${contactEmail}`}>Email</a></li><li><a href={instagramUrl} target="_blank" rel="noreferrer">Instagram</a></li>{whatsappContacts.map(([number, href]) => <li key={number}><a href={href} target="_blank" rel="noreferrer">WhatsApp {number}</a></li>)}<li><a href="#contact">Get a preview</a></li></ul></div></div><div className="footer-bottom"><span>© 2026 FieldScale AI</span><span>Powered by AI Lead Intelligence</span></div></footer>;
}

function App() {
  useEffect(() => {
    document.documentElement.classList.add('dark');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);
  return <><Header /><main><Hero /><Stats /><HowItWorks /><Services /><Process /><Proof /><Pricing /><Manifesto /><FAQ /><Contact /></main><Footer /></>;
}

export default App;