# FieldScale AI Website

Standalone deployment package for the FieldScale AI marketing website.

## Option 1: Deploy the included static build

Upload the contents of `dist/` to any static hosting provider:

- Vercel
- Netlify
- Cloudflare Pages
- GitHub Pages
- Any standard web server

Set the publish/output directory to `dist`.

## Option 2: Deploy from source

Requirements:

- Node.js 20.19+ or Node.js 22+
- npm, pnpm, or another Node package manager

Install and build:

```bash
npm install
npm run build
```

The production files will be generated in `dist/`.

To preview locally:

```bash
npm run preview
```

## Contact form behavior

The **Send Inquiry** button opens a pre-filled email addressed to:

`fieldscale.ai@gmail.com`

The visitor's email application must be configured for the `mailto:` action to open.

## Demo project button

The glowing **View Our Demo Project** button opens the configured Google Drive folder in a new tab.